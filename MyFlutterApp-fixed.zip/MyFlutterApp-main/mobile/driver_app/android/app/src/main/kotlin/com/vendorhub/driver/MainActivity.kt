package com.vendorhub.driver

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
